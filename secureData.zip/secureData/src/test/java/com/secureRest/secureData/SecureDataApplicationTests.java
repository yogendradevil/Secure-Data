package com.secureRest.secureData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
